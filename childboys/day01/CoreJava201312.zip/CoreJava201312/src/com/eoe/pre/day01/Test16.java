package com.eoe.pre.day01;

public class Test16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i=65;i<=90;i++){
			System.out.println((char)i+":"+i);
		}
	}

}
