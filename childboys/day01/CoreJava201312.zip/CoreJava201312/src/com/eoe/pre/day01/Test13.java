package com.eoe.pre.day01;

public class Test13 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		char c='A';
		while(c<='Z'){
			System.out.println(c+":"+(int)c);
			c++;
		}
	}

}
