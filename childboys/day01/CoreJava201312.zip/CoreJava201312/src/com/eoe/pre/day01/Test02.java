package com.eoe.pre.day01;

public class Test02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("5+3="+(5+3));
		System.out.println("5-3="+(5-3));
		System.out.println("5*3="+5*3);
		System.out.println("5/3="+5/3);
		System.out.println(Math.abs(-5));
		System.out.println(Math.sqrt(121));
		System.out.println(Math.round(3.75*10)/10.0);
		System.out.println(Math.pow(3, 4));
	}

}
